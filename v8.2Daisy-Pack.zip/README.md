# All in one Dasiy Pack
### - MIUI Cameara:
 - 4k video recording
 - 4, 8, 16, 32/s long exposure

- Pixel theme
- Pixel sounds
- Dual speaker mod
- Dark UI theme
- Black UI theme
- Notch Killer
- Network activty indicator disabler

#### type "su -c "dnai" on terminal to use
